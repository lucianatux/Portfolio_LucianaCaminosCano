package com.portfolioBackend.LCC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LccApplication {

	public static void main(String[] args) {
		SpringApplication.run(LccApplication.class, args);
	}

}
